/**
 * Created by Administrator on 2016/2/26.
 */

/**
 * 组件安装
 * npm install gulp-util gulp-imagemin gulp-ruby-sass gulp-minify-css gulp-jshint gulp-uglify gulp-rename gulp-concat gulp-clean gulp-livereload tiny-lr --save-dev
 */

var gulp    = require('gulp'),                 //基础库
    imagemin = require('gulp-imagemin'),       //图片压缩
    sass = require('gulp-ruby-sass'),          //sass
    gulpsass = require('gulp-sass'),          //sass
    minifycss = require('gulp-minify-css'),    //css压缩
    jshint = require('gulp-jshint'),           //js检查
    uglify  = require('gulp-uglify'),          //js压缩
    rename = require('gulp-rename'),           //重命名
    concat  = require('gulp-concat'),          //合并文件
    clean = require('gulp-clean'),             //清空文件夹
    tinylr = require('tiny-lr'),
    watch = require('gulp-watch'),
    server = tinylr(),
    port = 35729,
    livereload = require('gulp-livereload');   //livereload
gulp.task('minifycss', function() {
    return gulp.src('src/*.css')      //压缩的文件
        .pipe(minifycss())  //执行压缩
        .pipe(rename({suffix: '.min'}))
        .pipe(gulp.dest('minified'));   //输出文件夹

});
gulp.task('minifyjs', function() {
    // 1. 找到文件
    return gulp.src('src/*.js')
        // 2. 压缩文件
        .pipe(uglify())
        .pipe(rename({suffix: '.min'}))
        // 3. 另存压缩后的文件
        .pipe(gulp.dest('minified'))
});
gulp.task('default', function () {
    // 1. 找到文件
    return gulp.src('demo/*.js')
        .pipe(watch('demo/*.js'))
        // 2. 压缩文件
        .pipe(uglify())
        .pipe(rename({suffix: '.min'}))
        // 3. 另存压缩后的文件
        .pipe(gulp.dest('minified'))
});
gulp.task('minifyjqueryui', function() {
    // 1. 找到文件
    return gulp.src('src/ueditor.all.js')
        // 2. 压缩文件
        .pipe(uglify())
        .pipe(rename({suffix: '.min'}))
        // 3. 另存压缩后的文件
        .pipe(gulp.dest('minified'))
});
gulp.task('sass', function() {
    // 1. 找到文件
    return gulp.src('src/index.scss')
        // 2. 压缩文件
        .pipe(gulpsass())
        .pipe(gulp.dest('minified'))
});