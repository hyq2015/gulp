/**
 * Created by Administrator on 2016/6/29.
 */
console.log('ricky love');
console.log('hello');